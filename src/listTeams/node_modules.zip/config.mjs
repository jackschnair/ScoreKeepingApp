export const config = {
    "host"  : "scorekeepingdb.c9eiiyy2g1g2.us-east-2.rds.amazonaws.com",
    "user"  : "scAdmin",
    "password"  : "ScoreKeeping$123",
    "database"  : "scorekeeping"
}
